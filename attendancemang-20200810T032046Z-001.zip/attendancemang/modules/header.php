<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title> Attendence Tracker | Cross it!</title>
    
    <link href="css/bootstrap.min.css" rel="stylesheet">   
		<link href="css/style.css" rel="stylesheet">
		<script src="js/jquery.min.js"></script>
		<script src="js/validator.min.js"></script>
  </head>
  <body>
  	<div id="wrapper">
		<div class="overlay"></div>