# mattendance

#Installation

1. Install wamp/xampp server.